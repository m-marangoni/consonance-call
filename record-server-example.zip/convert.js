// const ffmpeg = require("ffmpeg");

// try{
//     var process = new ffmpeg("/messages")
//     process.then( function (audio){
//         //callback mode
//         audio.fnExtractSoundToMP3("/messsages/new/file.mp3"),  function(error, file){
//             if (!error) {
//             console.log('audio file: '+ file);
//          } };
//     }, function (err) {
//         console.log('error: ' + err);
//     });
// }
// catch (e) {
//     console.log(e.code);
//     console.log(e.msg);

// }